#ifndef HOOK_H
#define HOOK_H
bool HookOnScriptLoad();
#endif